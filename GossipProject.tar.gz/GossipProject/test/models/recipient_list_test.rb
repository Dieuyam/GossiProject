require 'test_helper'

class RecipientListTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
